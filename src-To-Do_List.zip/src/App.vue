<template>
  <div class="todo-container">
    <h1>
      <input
        type="text"
        v-model="newTask"
        @keyup.enter="addTask"
        placeholder="Add New Task Here"
      />
    </h1>

    <ul>
      <li v-for="(task, index) in tasks" :key="index">
        <span> {{ task }} </span>
        <button @click="removeTask(index)">Remove</button>
      </li>
    </ul>

    <div v-if="tasks.length > 0">
      <p>{{ tasks.length }}tasks remaning</p>
    </div>
  </div>
</template>

<script>
export default {
  data() {
    return {
      newTask: "",
      tasks: [],
    };
  },

  methods: {
    addTask() {
      if (this.newTask.trim() !== "") {
        this.tasks.push(this.newTask);
        this.newTask = "";
      }
    },

    removeTask(index) {
      this.tasks.splice(index, 1);
    },
  },
};
</script>

<style>
.todo-container {
  max-width: 400px;
  margin: auto;
  padding: 20px;
  text-align: center;
  background-color: antiquewhite;
  border-radius: 8px;
  box-shadow: 0 4px 8px rgb(0, 0, 0, 0.1);
}

h1 {
  font-size: 24px;
  color: #333;
}

input {
  width: 150px;
  padding: 10px;
  margin-bottom: 15px;
  font-size: 16px;
  border: 1px solid #ccc;
  border-radius: 4px;
}

li {
  display: flex;
  justify-content: space-between;
  align-items: center;
  padding: 8px;
  border-bottom: 1px solid #ddd;
}

button {
  background-color: red;
  color: white;
  border: none;
  padding: 5px 10px;
  border-radius: 4px;
  cursor: pointer;
}
button:hover {
  background-color: darkred;
}

p {
  font-size: 14px;
  color: #888;
}
</style>
